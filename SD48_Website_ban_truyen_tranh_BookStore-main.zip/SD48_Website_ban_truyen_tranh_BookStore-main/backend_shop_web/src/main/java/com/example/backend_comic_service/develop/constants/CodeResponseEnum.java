package com.example.backend_comic_service.develop.constants;

public class CodeResponseEnum {
    public static int SUCCESS = 200;
    public static int ERROR = 500;
}
