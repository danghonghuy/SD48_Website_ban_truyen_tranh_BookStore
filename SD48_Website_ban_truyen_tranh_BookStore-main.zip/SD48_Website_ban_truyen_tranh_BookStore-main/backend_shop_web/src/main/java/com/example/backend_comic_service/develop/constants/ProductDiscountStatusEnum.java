package com.example.backend_comic_service.develop.constants;

public class ProductDiscountStatusEnum {
    public static final Integer ACTIVE = 1;
    public static final Integer INACTIVE = 0;
}
