package com.example.backend_comic_service.develop.constants;

public class TypeDiscountEnum {
    public static final Integer DISCOUNT_PRICE = 1;
    public static final Integer DISCOUNT_PERCENT = 2;
}
