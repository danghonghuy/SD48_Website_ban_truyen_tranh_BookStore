package com.example.backend_comic_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendComicServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
