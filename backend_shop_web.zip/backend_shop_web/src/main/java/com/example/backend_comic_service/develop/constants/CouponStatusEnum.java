package com.example.backend_comic_service.develop.constants;

public class CouponStatusEnum {
    public static final Integer COUPON_STATUS_ACTIVE = 1;
    public static final Integer COUPON_STATUS_INACTIVE = 0;
    public static final Integer COUPON_STATUS_EXPIRE = 2;
}
