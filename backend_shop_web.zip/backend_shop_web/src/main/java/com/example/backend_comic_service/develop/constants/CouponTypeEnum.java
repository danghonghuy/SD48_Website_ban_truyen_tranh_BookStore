package com.example.backend_comic_service.develop.constants;

public class CouponTypeEnum {
    public static final Integer COUPON_PERCENT = 1;
    public static final Integer COUPON_MONEY = 2;
}
