package com.example.backend_comic_service.develop.repository;

import com.example.backend_comic_service.develop.entity.LogActionOrderEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogActionOrderRepository extends JpaRepository<LogActionOrderEntity, Integer> {
}
