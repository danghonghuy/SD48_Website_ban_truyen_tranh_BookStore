-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[employee_generateCode]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
/*	SET NOCOUNT OFF;
	DECLARE @codeGen varchar(50), @idLastest INT = 0
	SELECT @idLastest = MAX(e.id) FROM [dbo].[employee] as e
	IF(ISNULL(@idLastest, 0) <= 0)
	  BEGIN
	    SET @idLastest = 0;
	  END
	SET @idLastest = @idLastest + 1;
	SET @codeGen = RIGHT('000000' + CAST(@idLastest AS VARCHAR(6)), 6);
	SET @codeGen = 'EMP' + @codeGen;
	SELECT @codeGen;
	*/
	select 'test'
END
go

