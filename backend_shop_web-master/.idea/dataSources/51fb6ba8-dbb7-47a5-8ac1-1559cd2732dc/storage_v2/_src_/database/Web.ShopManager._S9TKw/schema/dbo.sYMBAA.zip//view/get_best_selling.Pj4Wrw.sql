create view [dbo].[get_best_selling] as
select product_id, count(*) as count_sell
from order_detail
group by product_id
go

